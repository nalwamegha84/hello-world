## MidtermSeptember2019


### Submission Process : 
- Deadline for the Midterm is 16th September, Monday Night. 
- Download the zip of the project --> unzip and open using Intellij --> File --> New --> Project Using Existing Source --> Select the downloaded project's root directory --> Create Project From Existing Source --> Next --> Next --> Next --> Next
- Make sure to add all the lib into your Library of Intellij if not added
- Create your own repository in github --> make sure your `git remote -v` pointing to your newly created repository (if not, changeusing git remote set-url) --> push the code in an problem solving basis, which means once one problem is solved, add, commit & push
- Once your github repo is created, share your github url of the midterm here at --> [click me](https://forms.gle/wNUN3vb51J9254eP8)

### FYI :
- You have to complete all the coding problems.
- Read the questions, there are some code here and there for you guys to spend time with. Try to understand them how they are working.
- Feel free to google. But don't feel free to copy and paste the answer. Try to understand and implement the answers. 
- I would have somebody randomly picked from the class and ask to present on one problem's solution from their submission of the midterm on coming tuesday.


# BEST OF LUCK
